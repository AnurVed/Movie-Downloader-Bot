# bot.py
import os
from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, CallbackContext
from telegram.ext import filters  # Updated import
from google.cloud import storage
from config import TELEGRAM_TOKEN, GOOGLE_CLOUD_BUCKET

# Initialize Google Cloud Storage client
storage_client = storage.Client()
bucket = storage_client.bucket(GOOGLE_CLOUD_BUCKET)

def start(update: Update, context: CallbackContext) -> None:
    update.message.reply_text('Welcome to the Movie Bot! Use /search <movie_name> to find movies.')

def search(update: Update, context: CallbackContext) -> None:
    movie_name = ' '.join(context.args)
    if not movie_name:
        update.message.reply_text('Please provide a movie name after /search.')
        return

    # Here, you would implement your logic to search for the movie in your storage
    # For simplicity, let's assume you have a function called find_movie
    movie_link = find_movie(movie_name)

    if movie_link:
        update.message.reply_text(f'Here is your movie link: {movie_link}')
    else:
        update.message.reply_text('Movie not found.')

def find_movie(movie_name: str) -> str:
    # This function should check your Google Cloud Storage for the movie
    # For now, we will return a placeholder link
    return f'https://storage.googleapis.com/{GOOGLE_CLOUD_BUCKET}/{movie_name}.mp4'

def main() -> None:
    updater = Updater(TELEGRAM_TOKEN)

    updater.dispatcher.add_handler(CommandHandler('start', start))
    updater.dispatcher.add_handler(CommandHandler('search', search))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
