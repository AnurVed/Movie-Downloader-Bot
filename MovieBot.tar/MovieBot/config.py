# config.py
TELEGRAM_TOKEN = '7451461749:AAEm-bFFFquZCsszQwZn7GQVoJTFJnKQYko'
GOOGLE_CLOUD_BUCKET = 'movie-downloader-bot'
